package com.dirt;

import net.fabricmc.api.ClientModInitializer;

public class DirtClient implements ClientModInitializer {
    public static final String NAME = "Dirt Client";
    public static final String VERSION = "1.0.0";

    @Override
    public void onInitializeClient() {
        System.out.println("[DirtClient] Загружен! Версия: " + VERSION);
    }
}
